package com.masai;

	public class Demo {
		public static void main(String[] args) {
			System.out.println("Name: Amandeep Kaur");
			System.out.println("Father's Name: Avtar Singh");
			System.out.println("Mother's Name: Tarsaim Kaur");
			System.out.println("Age: 24");
			System.out.println("Gender: Female");
			System.out.println("Address: Bangalore");
			System.out.println("Mobile Number: 7975653566");
		}
	}